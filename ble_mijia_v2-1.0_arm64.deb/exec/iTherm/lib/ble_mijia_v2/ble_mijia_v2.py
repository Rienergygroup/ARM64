from bluepy import btle
from datetime import datetime
from threading import Thread
from gestione_dispositivi import Master
from traceback import format_exc as stackErrore
from rienergy_ble_scanner import ThreadBleScanner

import pathlib
import sys
import time

import pytz

pathCorrente = pathlib.Path(__file__).parent.parent.parent.resolve().as_posix()
sys.path.append(pathCorrente)

import rienergy_logger
import rienergy_mqtt
import scrivi_misure
import chiamate_service

scriviLog = rienergy_logger.getLogger(pathLog=pathCorrente)

FORMAT_DATA_TZ = "%Y-%m-%d %H:%M:%S.%f%z"

TZ_UTC = pytz.utc

class MeasureDelegate(btle.DefaultDelegate):
    """
    Classe per gestire la notifica delle misure del sensore
    """
    def __init__(self):
        btle.DefaultDelegate.__init__(self)
        self.letto = False
        self.temp = None
        self.hum = None
        self.voltage = None
        self.battery = None
        self.offset = 0.1
        self.maxV = 3.28
        self.minV = 2.7
        self.deltaV = self.maxV - self.minV

    def handleNotification(self, cHandle, data):
        try:
            self.letto = True
            data = data.hex().upper()
            self.temp = int(data[2] + data[3] + data[0] + data[1], 16) / 100
            self.hum = int(data[4] + data[5], 16)
            self.voltage =  int(data[8] + data[9] + data[6] + data[7], 16) / 1000
            self.voltage += self.offset
            self.battery = int(((self.voltage - self.minV) * 100) / self.deltaV)
            self.battery = self.battery if self.battery <= 100 else 100
            self.battery = self.battery if self.battery >= 0 else 0

            
        except Exception as e:
            scriviLog.error("Errore recupero valore mijia-V2 %s\n%s", e, stackErrore())
            self.letto = False


class ThreadDispositivo(Thread):
    """Thread che recupera i dati del dispositivo ogni intervallo
    """
    def __init__(self, nome:str, dispositivo:dict, mqtts:dict, infoUtente:dict, master:Master, threadMisure:scrivi_misure.ProcessScrittuaFileMisure, configDispositivi:dict):
        Thread.__init__(self, name=nome)
        self.fine = False
        self.dispositivo = dispositivo
        self.mqtts = mqtts
        self.infoUtente = infoUtente
        self.configDispositivi = configDispositivi
        self.master = master
        self.threadMisure = threadMisure
        self.topicInfo = rienergy_mqtt.TOPIC_INFO.format(codDb=infoUtente["cod_db"], idUtente=infoUtente["id_utente"], idCentralina=infoUtente["id_centralina"])

    def run(self):
        while not self.fine:
            status = self.main()
            # Se la lettura del sensore è avvenuta correttamente attendo il suo tempo di intervallo,
            #  altrimenti ritento dopo pochi secondi
            msgStatus = rienergy_mqtt.TEMPLATE_MSG_STATUS_DEVICE
            msgStatus["id_dispositivo"] = self.dispositivo["id"]
            if status:
                msgStatus["status"] = True
                rienergy_mqtt.inviaMessaggio(msg=msgStatus, topic=self.topicInfo, mqtts=self.mqtts, filterMqtt="com")
                time.sleep(int(self.dispositivo["intervallo"]))
            else:
                msgStatus["status"] = False
                rienergy_mqtt.inviaMessaggio(msg=msgStatus, topic=self.topicInfo, mqtts=self.mqtts, filterMqtt="com")
                time.sleep(self.configDispositivi["intervallo_errore"])


    def main(self:dict) -> bool:
        """Funzione che recupera i dati del dispositivo e li scrive nel file misure e in mqtt
    
        Args:
            self (dict): Istanza del thread contenente il JSON del dispositivo
        
        Returns:
            Boolean: Ritrona True se è stato letto tutto correttamente, False se si sono verficati errori
        """
        try:
            bleScanner:ThreadBleScanner =  self.master.getThreadBleScanner()
            scriviLog.info("Recupero dati per il dispositivo %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
            devices = []
            found = False
            try:
                if bleScanner is not None:
                    devices = bleScanner.getDispositiviTrovati()
            except Exception as e:
                scriviLog.error("Errore nel main di ble_qingping_th_cgg1.py: %s\n%s", e, stackErrore())
                pass
            for d in devices:
                if d.addr.upper() == self.dispositivo["mac"].upper():
                    found = True
                    measureDelegate = MeasureDelegate()
                    val = b'\x01\x00'
                    
                    p = btle.Peripheral()
                    p.connect(self.dispositivo["mac"])
                    p.setDelegate(measureDelegate)
                    p.writeCharacteristic(0x0038,val,True)
                    p.writeCharacteristic(0x0046,b'\xf4\x01\x00',True)
                          
                    scriviLog.info("In attesa di notifica dei dati dal dispositivo %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])  
                    if p.waitForNotifications(20):
                        pass
                    if measureDelegate.letto:
                        dataLettura = datetime.utcnow().replace(tzinfo=TZ_UTC).strftime(FORMAT_DATA_TZ) 
                        scriviLog.info(self.dispositivo["descrizione"] + " " + self.dispositivo["mac"] + 
                                        "\n Temperatura: %s   Umidita: %s  Voltaggio: %s Batteria %s", 
                                        measureDelegate.temp, measureDelegate.hum, measureDelegate.voltage, measureDelegate.battery)
                        misuraTemp = None
                        misuraHum = None
                        try:
                            if measureDelegate.temp is not None:
                                misuraTemp = {
                                    "id_sensore": self.dispositivo["id"],
                                    "mac": self.dispositivo["mac"],
                                    "val_misura": measureDelegate.temp, 
                                    "tipo_misura": "Celsius", 
                                    "nome_misura": "Temperatura", 
                                    "cod_db": self.infoUtente["cod_db"],
                                    "id_utente": self.infoUtente["id_utente"],
                                    "id_centralina": self.dispositivo["fk_centralina"],
                                    "dt_misura": dataLettura, 
                                    "rssi": "0"
                                }
                        except: pass
                        try:
                            if measureDelegate.hum is not None:
                                misuraHum = {
                                    "id_sensore": self.dispositivo["id"],
                                    "mac": self.dispositivo["mac"],
                                    "val_misura": measureDelegate.hum, 
                                    "tipo_misura": "%", 
                                    "nome_misura": "Umidita", 
                                    "cod_db": self.infoUtente["cod_db"],
                                    "id_utente": self.infoUtente["id_utente"],
                                    "id_centralina": self.dispositivo["fk_centralina"],
                                    "dt_misura": dataLettura, 
                                    "rssi": "0"
                                }
                        except: pass

                        lowBat = measureDelegate.battery <= 15
                        datiUtente = {"id_utente": self.infoUtente["id_utente"], "id_centralina": self.dispositivo["fk_centralina"], "cod_db": self.infoUtente["cod_db"]}
                        chiamate_service.updateBatteriaScarica(self.dispositivo["id"], lowBat, mqtts=self.mqtts, datiUtente=datiUtente, percBatteria=measureDelegate.battery)

                        self.threadMisure.scriviMisure(self.mqtts, misuraTemp, misuraHum)
                        
                        try:
                            p.disconnect()
                        except: pass

                        return True
                    else:
                        scriviLog.info("Timeout nel ricevere la notifica con i valori %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])

        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, stackErrore())
        try:
            p.disconnect()
        except: pass

        if not found:
            scriviLog.error("Non sono riuscito a trovare %s nella lista dei dispositivi BLE", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])

        return False
        

def main(dispositivo:dict, mqtts:dict, infoUtente:dict, **kwargs) -> Thread:
    """Funzione che avvia il thread di lettura del dispositivo

    Args:
        dispositivo (dict): Dispositivo da leggere
        mqtts (dict): Lista di mqtt
        infoUtente (dict): Dati dell'utente

    Returns:
        Thread: Riferimento al thread del dispositivo
    """
    master = kwargs["master"] if "master" in kwargs else None
    threadMisure = kwargs["process_misure"] if "process_misure" in kwargs else None
    configDispositivi = kwargs["config_dispositivi"] if "config_dispositivi" in kwargs else {}
    threadDispositivo = ThreadDispositivo("thread_lettura_dispositivo-" + dispositivo["id"], dispositivo, mqtts, infoUtente, master, threadMisure, configDispositivi=configDispositivi)
    threadDispositivo.start()
    return threadDispositivo


if __name__ == "__main__":
    main({
        "id": "1",
        "descrizione": "Sensore bagno",
        "mac": "A4:C1:38:27:F9:3F",
        "url_interno": "",
        "url_esterno": "",
        "user": "",
        "password": "",
        "intervallo": "20",
        "alimentazione": "",
        "tensione": "",
        "nome_pacchetto": "a",
        "nome_eseguibile": "a.py"
    }, [], {"cod_db": "100", "id_utente": "1"})