from datetime import datetime
from threading import Thread
from gestione_dispositivi import Master
from rienergy_ble_scanner import ThreadBleScanner

import pathlib
import sys
import time
import traceback
import pytz

pathCorrente = pathlib.Path(__file__).parent.parent.parent.resolve().as_posix()
sys.path.append(pathCorrente)

import rienergy_logger
import rienergy_mqtt
import scrivi_misure
import chiamate_service

scriviLog = rienergy_logger.getLogger(pathLog=pathCorrente)

FORMAT_DATA_TZ = "%Y-%m-%d %H:%M:%S.%f%z"

TZ_UTC = pytz.utc

class ThreadDispositivo(Thread):
    """Thread che recupera i dati del dispositivo ogni intervallo
    """
    def __init__(self, nome:str, dispositivo:dict, mqtts:dict, infoUtente:dict, master:Master, threadMisure:scrivi_misure.ProcessScrittuaFileMisure, configDispositivi:dict):
        Thread.__init__(self, name=nome)
        self.fine = False
        self.dispositivo = dispositivo
        self.mqtts = mqtts
        self.infoUtente = infoUtente
        self.master = master
        self.threadMisure = threadMisure
        self.configDispositivi = configDispositivi
        self.topicInfo = rienergy_mqtt.TOPIC_INFO.format(codDb=infoUtente["cod_db"], idUtente=infoUtente["id_utente"], idCentralina=infoUtente["id_centralina"])
        self.found = False

    def run(self):
        while not self.fine:
            status = self.main()
            # Se la lettura del sensore è avvenuta correttamente attendo il suo tempo di intervallo,
            #  altrimenti ritento dopo pochi secondi
            msgStatus = rienergy_mqtt.TEMPLATE_MSG_STATUS_DEVICE
            msgStatus["id_dispositivo"] = self.dispositivo["id"]
            if status:
                msgStatus["status"] = self.found
                rienergy_mqtt.inviaMessaggio(msg=msgStatus, topic=self.topicInfo, mqtts=self.mqtts, filterMqtt="com")
                time.sleep(30)
                # time.sleep(int(self.dispositivo["intervallo"]))
            else:
                msgStatus["status"] = self.found
                rienergy_mqtt.inviaMessaggio(msg=msgStatus, topic=self.topicInfo, mqtts=self.mqtts, filterMqtt="com")
                time.sleep(self.configDispositivi["intervallo_errore"])


    def main(self) -> bool:
        """Funzione che recupera i dati del dispositivo e li scrive nel file misure e in mqtt
    
        Args:
            self (dict): Istanza del thread contenente il JSON del dispositivo
        
        Returns:
            Boolean: Ritrona True se è stato letto tutto correttamente, False se si sono verficati errori
        """
        try:
            scriviLog.info("Recupero dati per il dispositivo %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
            # devices = await BleakScanner.discover()
            # d = await BleakScanner.find_device_by_address(self.dispositivo["mac"], timeout=5)
            bleScanner:ThreadBleScanner =  self.master.getThreadBleScanner()
            devices = []
            self.found = False
            try:
                if bleScanner is not None:
                    devices = bleScanner.getDispositiviTrovati()
            except Exception as e:
                scriviLog.error("Errore nel main di ble_qingping_th_cgg1.py: %s\n%s", e, traceback.format_exc())
                pass
            for d in devices:
                if d.addr.upper() == self.dispositivo["mac"].upper():
                    self.found = True
                    dati = d.rawData.hex().upper()
                    dataLettura = datetime.utcnow().replace(tzinfo=TZ_UTC).strftime(FORMAT_DATA_TZ)
                    arr_mac_tmp = self.dispositivo["mac"].upper().split(":")
                    mac_tmp = ""
                    for i_mac in reversed(arr_mac_tmp):
                        mac_tmp += i_mac
                    
                    if mac_tmp in dati:
                        # Se il mac non è presente nei dati ignoro i dati ricevuti e attendo la prossima scansione
                        n = dati.find(mac_tmp)+len(mac_tmp)+4
                        dati = dati[n:]
                        temp = int(dati[2] + dati[3] + dati[0] + dati[1], 16) / 10
                        hum = int(dati[6] + dati[7] + dati[4] + dati[5], 16) / 10
                        bat = int(dati[12:14], 16)
                        # Batteria bassa
                        lowBat = bat <= 15
                        datiUtente = {"id_utente": self.infoUtente["id_utente"], "id_centralina": self.dispositivo["fk_centralina"], "cod_db": self.infoUtente["cod_db"]}
                        chiamate_service.updateBatteriaScarica(self.dispositivo["id"], lowBat, mqtts=self.mqtts, datiUtente=datiUtente, percBatteria=bat)

                        scriviLog.info(self.dispositivo["descrizione"] + " " + self.dispositivo["mac"] + "\n Temperatura: %s   Umidita: %s  Batteria: %s", 
                        temp, hum, bat)
                            
                        misuraTemp = {
                            "id_sensore": self.dispositivo["id"],
                            "mac": self.dispositivo["mac"],
                            "val_misura": temp, 
                            "tipo_misura": "°C", 
                            "nome_misura": "Temperatura", 
                            "cod_db": self.infoUtente["cod_db"],
                            "id_utente": self.infoUtente["id_utente"],
                            "id_centralina": self.dispositivo["fk_centralina"],
                            "dt_misura": dataLettura, 
                            "rssi": d.rssi
                        }
                        misuraHum = {
                            "id_sensore": self.dispositivo["id"],
                            "mac": self.dispositivo["mac"],
                            "val_misura": hum, 
                            "tipo_misura": "%", 
                            "nome_misura": "Umidita", 
                            "cod_db": self.infoUtente["cod_db"],
                            "id_utente": self.infoUtente["id_utente"],
                            "id_centralina": self.dispositivo["fk_centralina"],
                            "dt_misura": dataLettura, 
                            "rssi": d.rssi
                        }

                        self.threadMisure.scriviMisure(self.mqtts, misuraTemp, misuraHum)

                        # *** TEST ***
                        misure2Schermo = {
                            "id_sensore": self.dispositivo["id"],
                            "grandezze": ["Temperatura", "RH", "Batteria"],
                            "valori": [temp, hum, bat],
                            "unita_misura": ["°C", "%", "%"],
                            "colori": [0xFE5F55, 0x386FA4, 0x495867],
                            "colori_testo": [0xFFFF, 0xFFFF, 0xFFFF]
                        }
                        self.threadMisure.scriviMisureSchermo(self.mqtts, "itherm/watch/94E686381B64/misure", misure2Schermo)
                        return True

        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
        if not self.found:
            scriviLog.error("Non sono riuscito a trovare %s nella lista dei dispositivi BLE", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
        return False

def main(dispositivo:dict, mqtts:dict, infoUtente:dict, **kwargs) -> Thread:
    """Funzione che avvia il thread di lettura del dispositivo

    Args:
        dispositivo (dict): Dispositivo da leggere
        mqtts (dict): Lista di mqtt
        infoUtente (dict): Dati dell'utente

    Returns:
        Thread: Riferimento al thread del dispositivo
    """
    master = kwargs["master"] if "master" in kwargs else None
    threadMisure = kwargs["process_misure"] if "process_misure" in kwargs else None
    configDispositivi = kwargs["config_dispositivi"] if "config_dispositivi" in kwargs else {}
    threadDispositivo = ThreadDispositivo("thread_lettura_dispositivo-" + dispositivo["id"], dispositivo, mqtts, infoUtente, master, threadMisure, configDispositivi=configDispositivi)
    threadDispositivo.start()
    return threadDispositivo



if __name__ == "__main__":
    main({
        "id": "1",
        "descrizione": "Sensore camera",
        "mac": "58:2D:34:12:89:3F",
        "url_interno": "",
        "url_esterno": "",
        "user": "",
        "password": "",
        "intervallo": "20",
        "alimentazione": "",
        "tensione": "",
        "nome_pacchetto": "a",
        "nome_eseguibile": "a.py"
    }, [], {"cod_db": "100", "id_utente": "1"})