from datetime import datetime
from requests.structures import CaseInsensitiveDict

import pathlib
import sys
import traceback
import requests
import pytz

pathCorrente = pathlib.Path(__file__).parent.parent.parent.resolve().as_posix()
sys.path.append(pathCorrente)

import rienergy_logger
import scrivi_misure

scriviLog = rienergy_logger.getLogger(pathLog=pathCorrente)

FORMAT_DATA_TZ = "%Y-%m-%d %H:%M:%S.%f%z"

TZ_UTC = pytz.utc

class Attuatore():
    """Classe contentente i riferimenti del dispositivo per l'attuazione e recupero dati
    """
    def __init__(self, nome:str, dispositivo:dict, mqtts:dict, infoUtente:dict, threadMisure:scrivi_misure.ProcessScrittuaFileMisure):
        self.fine = False
        self.nome = nome
        self.dispositivo = dispositivo
        self.mqtts = mqtts
        self.infoUtente = infoUtente
        self.threadMisure = threadMisure
        self.subscribeMqtt()
        self.ultimiValori = scrivi_misure.getMisureByDispositivoEGrandezza(idDispositivo=dispositivo["id"], numMisure=1, grandezze=["energia"])

    def subscribeMqtt(self) -> None:
        """
        Funzione per sottoscriversi ai canali mqtt sui quali il dispositivo invierà i dati
        """
        for mqtt in self.mqtts:
            self.mqtts[mqtt]["rif_thread"].getClient().subscribe("shellies/{mac}/relay/0/power".format(mac=self.dispositivo["mac"]))
            self.mqtts[mqtt]["rif_thread"].getClient().subscribe("shellies/{mac}/relay/0/energy".format(mac=self.dispositivo["mac"]))
            self.mqtts[mqtt]["rif_thread"].getClient().subscribe("shellies/{mac}/relay/0".format(mac=self.dispositivo["mac"]))

    def is_alive(self) -> bool:
        """
        Funzione creata per rendere la classe sempre attiva per lo smistatore dei dispositivi

        Returns:
            bool: Sempre True
        """
        return True

    def getName(self) -> str:
        """
        Funzione che torna il nome della classe (contentente l'id del dispositivo)

        Returns:
            str: Nome passato alla classe alla creazione
        """
        return self.nome

    def getInfoDispositivo(self) -> dict:
        """
        Funzione che ritorna le info del dispositivo

        Returns:
            dict: Info del dispositivo
        """
        return self.dispositivo

    def setStatusAttuazione(self, status:dict) -> None:
        """
        Funzione che attiva disattiva il relay associato al dispositivo di attuazione

        Args:
            status (dict): Stato dell'attuazione [es. {"value": True|False}]
        """
        topicAttuatore = "shellies/{mac}/relay/0/command".format(mac=self.dispositivo["mac"])
        if type(status["value"]) is str:
            statusRelay = "on" if status["value"].lower() in ["1.0", "true"]  else "off"
        else:
            statusRelay = "on" if status["value"] else "off"
        msgDaInviare = statusRelay

        # Gestisco il relay tramite mqtt
        for mqtt in self.mqtts:
            try:
                self.mqtts[mqtt]["rif_thread"].publish(topicAttuatore, msgDaInviare)
            except Exception as e:
                scriviLog.error("Errore invio status MQTT attuazione %s: %s\n%s",
                            self.dispositivo["descrizione"] + " " + self.dispositivo["mac"],
                            e, traceback.format_exc())

        # Attivazione del relay tramite chiamata diretta all'url (se presente)
        # for posUrl in ["url_interno", "url_esterno"]:
        #     url = self.dispositivo[posUrl]
        #     if url != None and url != "":
        #         try:
        #             url = url if "http" in url else "http://" + url
        #             url = url if url[-1] == "/" else url + "/"
        #             url = url + "relay/0?turn="+ statusRelay

        #             headers = CaseInsensitiveDict()
        #             headers["Content-Type"] = "application/json"
        #             requests.post(url, headers=headers, timeout=5)
        #         except Exception as e:
        #             scriviLog.error("Errore invio status URL attuazione %s: %s\n%s",
        #                      self.dispositivo["descrizione"] + " " + self.dispositivo["mac"],
        #                       e, traceback.format_exc())

    def gestisciLetturaAtt(self, dato:str, topic:str) -> None:
        """
        Funzione che gestisce il messaggio ricevuto dall'mqtt contentente i dati del dispositivo

        Args:
            dato (str): Dato misurato dal sensore
            topic (str): Topic sul quale è stato inviato il dato
        """
        topicAtt = "shellies/{mac}/relay/0".format(mac=self.dispositivo["mac"])
        dataLettura = datetime.utcnow().replace(tzinfo=TZ_UTC).strftime(FORMAT_DATA_TZ)
        lettura = {
                "id_sensore": self.dispositivo["id"],
                "mac": self.dispositivo["mac"],
                "val_misura": None, 
                "tipo_misura": None, 
                "nome_misura": None, 
                "cod_db": self.infoUtente["cod_db"],
                "id_utente": self.infoUtente["id_utente"],
                "id_centralina": self.dispositivo["fk_centralina"],
                "dt_misura": dataLettura, 
                "rssi": 0
            }
        try:
            if topicAtt + "/energy" in topic:
                try:
                    ultimoEnergia = float(self.ultimiValori["energia"][0]["val_misura"]) if "energia" in self.ultimiValori else 0
                except:
                    ultimoEnergia = 0
                dato = round(float(dato) / 60, 3) # Per trasformate in Wh
                dato2send = dato # Di default invio il dato ottenutp
                if dato >= ultimoEnergia: # Controllo che il dato ottenuto sia maggiore o uguale all'ultimo registrato
                    dato2send = dato - ultimoEnergia # Invio la differenza
                lettura["val_misura"] = str(dato2send)
                lettura["tipo_misura"] = "Wh"
                lettura["nome_misura"] = "Energia"

            elif topicAtt + "/power" in topic:
                lettura["val_misura"] = str(dato)
                lettura["tipo_misura"] = "W"
                lettura["nome_misura"] = "Potenza"

            elif topicAtt in topic:
                lettura["val_misura"] = "1" if str(dato).lower() == "on" else "0"
                lettura["tipo_misura"] = "On_Off"
                lettura["nome_misura"] = "Accensione"

            if lettura["val_misura"] != None:
                self.threadMisure.scriviMisure(self.mqtts, lettura)

        except Exception as e:
            scriviLog.error("Errore dispositivo attuazione %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())

    
def main(dispositivo:dict, mqtts:dict, infoUtente:dict, **kwargs) -> Attuatore:
    """Funzione che crea a classe dell'attuatore per gestire il dispositivo

    Args:
        dispositivo (dict): Dispositivo da leggere
        mqtts (list): Lista di mqtt
        infoUtente (dict): Dati dell'utente

    Returns:
        Attuatore: Riferimento all'attuatore del dispositivo
    """
    threadMisure = kwargs["process_misure"] if "process_misure" in kwargs else None
    attuatore = Attuatore("attuatore_dispositivo-" + dispositivo["id"], dispositivo, mqtts, infoUtente, threadMisure)
    return attuatore


if __name__ == "__main__":
    main({
        "id": "20",
        "descrizione": "Attuatore cucina",
        "mac": "shellypug-00",
        "url_interno": "",
        "url_esterno": "",
        "user": "",
        "password": "",
        "intervallo": "20",
        "alimentazione": "",
        "tensione": "",
        "nome_pacchetto": "a",
        "nome_eseguibile": "a.py"
    }, [], {"cod_db": "100", "id_utente": "1"})