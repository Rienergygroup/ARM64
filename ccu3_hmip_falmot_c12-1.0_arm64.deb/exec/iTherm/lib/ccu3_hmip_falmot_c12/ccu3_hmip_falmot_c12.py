from datetime import datetime
from threading import Thread

import pathlib
import sys
import time
import traceback
import asyncio
import xmlrpc.client
import pytz

import chiamate_service

pathCorrente = pathlib.Path(__file__).parent.parent.parent.resolve().as_posix()
sys.path.append(pathCorrente)

import rienergy_logger
import scrivi_misure
import chiamate_comuni

scriviLog = rienergy_logger.getLogger(pathLog=pathCorrente)

FORMAT_DATA_TZ = "%Y-%m-%d %H:%M:%S.%f%z"

TZ_UTC = pytz.utc

class ThreadDispositivo(Thread):
    """Thread che recupera i dati del dispositivo ogni intervallo
    """
    def __init__(self, nome:str, dispositivo:dict, mqtts:dict, infoUtente:dict):
        Thread.__init__(self, name=nome)
        self.fine = False
        self.dispositivo = dispositivo
        self.mqtts = mqtts
        self.infoUtente = infoUtente
        self.valorePrecedente = None

    def run(self):
        while not self.fine:
            status = asyncio.run(self.main())
            # Se la lettura del sensore è avvenuta correttamente attendo il suo tempo di intervallo,
            #  altrimenti ritento dopo pochi secondi
            if status:
                try:
                    if int(self.dispositivo["intervallo"]) <= 0: 
                        self.dispositivo["intervallo"] = 60
                except:
                    self.dispositivo["intervallo"] = 60
                time.sleep(int(self.dispositivo["intervallo"]))
            else:
                time.sleep(30)

    def getInfoDispositivo(self) -> dict:
        """
        Funzione che ritorna le info del dispositivo

        Returns:
            dict: Info del dispositivo
        """
        return self.dispositivo

    async def main(self:dict) -> bool:
        """Funzione che recupera i dati del dispositivo (se presenti) e li scrive nel file misure e in mqtt e controlla lo stato della valvola
    
        Args:
            self (dict): Istanza del thread contenente il JSON del dispositivo
        
        Returns:
            Boolean: Ritrona True se è stato letto tutto correttamente, False se si sono verficati errori
        """
        try:
            scriviLog.info("Recupero dati per il dispositivo %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
            user = chiamate_comuni.CCU3_USER
            password = chiamate_comuni.CCU3_PWD
            ip_centrale = chiamate_comuni.getIpCCU3()
            
            mac_xmlrpc = str(self.dispositivo["mac"])

            scriviLog.info("[CCU3] connessione a http://%s:%s@%s:2010/", user, password, ip_centrale)
            with xmlrpc.client.ServerProxy("http://"+user+":"+password+"@"+ip_centrale+":2010/") as proxy:
                proxy.init(ip_centrale, "1")           

                for canale in range (1, 13):
                    dati = proxy.getParamset(mac_xmlrpc + ":" + str(canale), "VALUES")
                    livello = None
                    try:
                        livello = float(dati["LEVEL"]) * 100
                    except: pass
                    # scriviLog.info("Flamot canale " +str(canale) + " : " + str(livello) )
                    if livello != None:
                        dataLettura = datetime.utcnow().replace(tzinfo=TZ_UTC).strftime(FORMAT_DATA_TZ)
                        try:
                            scrivi_misure.scriviMisura({
                                "id_sensore": self.dispositivo["id"],
                                "mac": self.dispositivo["mac"],
                                "val_misura": livello, 
                                "tipo_misura": "%", 
                                "nome_misura": "Apertura canale " + str(canale), 
                                "cod_db": self.infoUtente["cod_db"],
                                "id_utente": self.infoUtente["id_utente"],
                                "id_centralina": self.dispositivo["fk_centralina"],
                                "dt_misura": dataLettura, 
                                "rssi": "0"
                            }, self.mqtts)
                        except Exception as e:
                            scriviLog.error("Errore scrivi_misura di %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
                
                return True
        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
            pass
        return False

def main(dispositivo:dict, mqtts:dict, infoUtente:dict) -> Thread:
    """Funzione che avvia il thread di lettura del dispositivo

    Args:
        dispositivo (dict): Dispositivo da leggere
        mqtts (dict): Lista di mqtt
        infoUtente (dict): Dati dell'utente

    Returns:
        Thread: Riferimento al thread del dispositivo
    """
    threadDispositivo = ThreadDispositivo("thread_lettura_dispositivo-" + dispositivo["id"], dispositivo, mqtts, infoUtente)
    threadDispositivo.start()
    return threadDispositivo