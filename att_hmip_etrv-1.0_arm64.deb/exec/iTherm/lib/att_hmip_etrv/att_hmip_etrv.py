from datetime import datetime
from threading import Thread

import pathlib
import sys
import time
import traceback
import xmlrpc
import pytz

pathCorrente = pathlib.Path(__file__).parent.parent.parent.resolve().as_posix()
sys.path.append(pathCorrente)

import rienergy_logger
import scrivi_misure

scriviLog = rienergy_logger.getLogger(pathLog=pathCorrente)

FORMAT_DATA_TZ = "%Y-%m-%d %H:%M:%S.%f%z"

TZ_UTC = pytz.utc

class Attuatore(Thread):
    """Classe contentente i riferimenti del dispositivo per l'attuazione e recupero dati
    """
    def __init__(self:dict, nome:str, dispositivo:dict, mqtts:dict, infoUtente:dict):
        self.fine = False
        self.nome = nome
        self.dispositivo = dispositivo
        self.mqtts = mqtts
        self.infoUtente = infoUtente
        self.valorePrecedente = None

    
    def run(self):
        while not self.fine:
            status = self.main()
            # Se la lettura del sensore è avvenuta correttamente attendo il suo tempo di intervallo,
            #  altrimenti ritento dopo pochi secondi
            if status:
                time.sleep(int(self.dispositivo["intervallo"]))
            else:
                time.sleep(30)


    def main(self:dict) -> bool:
        """Funzione che recupera i dati del dispositivo (se presenti) e li scrive nel file misure e in mqtt e controlla lo stato della valvola
        
        Returns:
            Boolean: Ritrona True se è stato letto tutto correttamente, False se si sono verficati errori
        """
        return self.letturaValvola()
    
    def getInfoDispositivo(self) -> dict:
        """
        Funzione che ritorna le info del dispositivo

        Returns:
            dict: Info del dispositivo
        """
        return self.dispositivo

    def setStatusAttuazione(self:dict, status:dict) -> bool:
        """
        Funzione che attiva disattiva il relay associato al dispositivo di attuazione

        Args:
            status (dict): Stato dell'attuazione [es. {"value": 22.5}]

        Returns:
            bool: True se la modifica è avvenuta con successo, False se si sono verificati errori
        """
        try:
            scriviLog.info("Recupero dati per il dispositivo %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
            user = self.dispositivo["user"]
            password = self.dispositivo["password"]
            ip_centrale = self.dispositivo["url_esterno"]
            
            mac_xmlrpc = str(self.dispositivo["mac"])
            if mac_xmlrpc.find(":1") == -1: mac_xmlrpc = mac_xmlrpc + ":1"

            scriviLog.info("[CCU3] connessione a http://%s:%s@%s:2010/", user, password, ip_centrale)
            with xmlrpc.client.ServerProxy("http://"+user+":"+password+"@"+ip_centrale+":2010/") as proxy:
                proxy.init(ip_centrale, "1")           
                proxy.setValue(mac_xmlrpc, "SET_POINT_TEMPERATURE", status["value"])
                self.salvaValoreValvolaSuDb(status["value"])

                return True
        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
        return False

    def letturaValvola(self:dict) -> bool:
        """
        Funzione legge la valvola e se diverso dal valore precedente aggiorna la configurazione di itherm[?termostato associato?] e salva il dato sul database

        Args:
            dato (str): Dato misurato dal sensore
            topic (str): Topic sul quale è stato inviato il dato

        Returns:
            bool: True se la lettura è avvenuta con successo, False se si sono verificati errori
        """
        try:
            scriviLog.info("Recupero dati per il dispositivo %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
            user = self.dispositivo["user"]
            password = self.dispositivo["password"]
            ip_centrale = self.dispositivo["url_esterno"]
            
            mac_xmlrpc = str(self.dispositivo["mac"])
            if mac_xmlrpc.find(":1") == -1: mac_xmlrpc = mac_xmlrpc + ":1"

            scriviLog.info("[CCU3] connessione a http://%s:%s@%s:2010/", user, password, ip_centrale)
            with xmlrpc.client.ServerProxy("http://"+user+":"+password+"@"+ip_centrale+":2010/") as proxy:
                proxy.init(ip_centrale, "1")               
                dati_valvola = proxy.getParamset(mac_xmlrpc, "VALUES")
                valore = dati_valvola["SET_POINT_TEMPERATURE"]
                if valore > 30:
                    valore = 30
                if valore < 5:
                    valore = 5
                if self.valorePrecedente != None:
                    if self.valorePrecedente != valore:
                        self.salvaValoreValvolaSuDb(valore)

                livelloApertura = None
                try:
                    livelloApertura = float(dati_valvola["LEVEL"]) * 100
                except: pass
                if livelloApertura != None:
                    dataLettura = datetime.utcnow().replace(tzinfo=TZ_UTC).strftime(FORMAT_DATA_TZ)
                    lettura = {
                            "id_sensore": self.dispositivo["id"],
                            "mac": self.dispositivo["mac"],
                            "val_misura": livelloApertura, 
                            "tipo_misura": "%", 
                            "nome_misura": "Apertura", 
                            "cod_db": self.infoUtente["cod_db"],
                            "id_utente": self.infoUtente["id_utente"],
                            "id_centralina": self.dispositivo["fk_centralina"],
                            "dt_misura": dataLettura, 
                            "rssi": 0
                        }
                    scrivi_misure.scriviMisura(lettura, self.mqtts)
                return True
        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
        return False

    def salvaValoreValvolaSuDb(self:dict, value:float) -> bool:
        """
        Funzione salva il valore passato sul database se è diverso da quello precedente

        Args:
            value (float): Valore della valvola

        Returns:
            bool: True se la lettura è avvenuta con successo, False se si sono verificati errori
        """
        try:
            if self.valorePrecedente != None:
                if self.valorePrecedente != value:
                    dataLettura = datetime.utcnow().replace(tzinfo=TZ_UTC).strftime(FORMAT_DATA_TZ)
                    lettura = {
                            "id_sensore": self.dispositivo["id"],
                            "mac": self.dispositivo["mac"],
                            "val_misura": value, 
                            "tipo_misura": "Valvola", 
                            "nome_misura": "Celsius", 
                            "cod_db": self.infoUtente["cod_db"],
                            "id_utente": self.infoUtente["id_utente"],
                            "dt_misura": dataLettura, 
                            "rssi": 0
                        }
                    
                    scrivi_misure.scriviMisura(lettura, self.mqtts)
                    self.valorePrecedente = value

            return True
        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
        return False

    
def main(dispositivo:dict, mqtts:dict, infoUtente:dict) -> Attuatore:
    """Funzione che crea a classe dell'attuatore per gestire il dispositivo

    Args:
        dispositivo (dict): Dispositivo da leggere
        mqtts (dict): Lista di mqtt
        infoUtente (dict): Dati dell'utente

    Returns:
        Attuatore: Riferimento all'attuatore del dispositivo
    """
    attuatore = Attuatore("attuatore_dispositivo-" + dispositivo["id"], dispositivo, mqtts, infoUtente)
    attuatore.start()
    attuatore.setStatusAttuazione({"value": 20})
    return attuatore


if __name__ == "__main__":
    main({
        "id": "69420",
        "descrizione": "Valvola termosifone",
        "mac": "000A1A499AE804",
        "url_interno": "192.168.1.11",
        "url_esterno": "192.168.1.11",
        "user": "Admin",
        "password": "Pass01!!",
        "intervallo": "20",
        "alimentazione": "",
        "tensione": "",
        "nome_pacchetto": "a",
        "nome_eseguibile": "a.py"
    }, [], {"cod_db": "100", "id_utente": "1"})