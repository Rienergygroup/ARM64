from datetime import datetime
from threading import Thread

import pathlib
import sys
import time
import traceback
import xmlrpc.client
import pytz


pathCorrente = pathlib.Path(__file__).parent.parent.parent.resolve().as_posix()
sys.path.append(pathCorrente)

import rienergy_logger
import scrivi_misure
import chiamate_comuni

scriviLog = rienergy_logger.getLogger(pathLog=pathCorrente)

FORMAT_DATA_TZ = "%Y-%m-%d %H:%M:%S.%f%z"

TZ_UTC = pytz.utc

class ThreadDispositivo(Thread):
    """Thread che recupera i dati del dispositivo ogni intervallo
    """
    def __init__(self, nome:str, dispositivo:dict, mqtts:dict, infoUtente:dict, threadMisure:scrivi_misure.ProcessScrittuaFileMisure):
        Thread.__init__(self, name=nome)
        self.fine = False
        self.dispositivo = dispositivo
        self.mqtts = mqtts
        self.infoUtente = infoUtente
        self.valorePrecedente = None
        self.threadMisure = threadMisure

    def run(self):
        while not self.fine:
            status = self.main()
            # Se la lettura del sensore è avvenuta correttamente attendo il suo tempo di intervallo,
            #  altrimenti ritento dopo pochi secondi
            if status:
                time.sleep(int(self.dispositivo["intervallo"]))
            else:
                time.sleep(30)

    def getInfoDispositivo(self) -> dict:
        """
        Funzione che ritorna le info del dispositivo

        Returns:
            dict: Info del dispositivo
        """
        return self.dispositivo

    def main(self:dict) -> bool:
        """Funzione che recupera i dati del dispositivo (se presenti) e li scrive nel file misure e in mqtt e controlla lo stato della valvola
    
        Args:
            self (dict): Istanza del thread contenente il JSON del dispositivo
        
        Returns:
            Boolean: Ritrona True se è stato letto tutto correttamente, False se si sono verficati errori
        """
        try:
            scriviLog.info("Recupero dati per il dispositivo %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
            user = chiamate_comuni.CCU3_USER
            password = chiamate_comuni.CCU3_PWD
            ip_centrale = chiamate_comuni.getIpCCU3()
            
            mac_xmlrpc = str(self.dispositivo["mac"])

            scriviLog.info("[CCU3] connessione a http://%s:%s@%s:2010/", user, password, ip_centrale)
            with xmlrpc.client.ServerProxy("http://"+user+":"+password+"@"+ip_centrale+":2010/") as proxy:
                proxy.init(ip_centrale, "1")           
                datiSensore = proxy.getParamset(mac_xmlrpc + ":5", "VALUES")
                
                dataLettura = datetime.utcnow().replace(tzinfo=TZ_UTC).strftime(FORMAT_DATA_TZ)

                energyCounter = datiSensore["ENERGY_COUNTER"] if "ENERGY_COUNTER" in datiSensore else None
                power = datiSensore["POWER"] if "POWER" in datiSensore else None
                current = (datiSensore["CURRENT"] / 1000) if "CURRENT" in datiSensore else None
                voltage = datiSensore["VOLTAGE"] if "VOLTAGE" in datiSensore else None
                frequency = datiSensore["FREQUENCY"] if "FREQUENCY" in datiSensore else None

                misuraEnergyCounter = None
                misuraPower = None
                misuraCurrent = None
                misuraVoltage = None
                misuraFrequency = None 

                if energyCounter != None:
                    misuraEnergyCounter = {
                        "id_sensore": self.dispositivo["id"],
                        "mac": self.dispositivo["mac"],
                        "val_misura": energyCounter, 
                        "tipo_misura": "Wh", 
                        "nome_misura": "Energia", 
                        "cod_db": self.infoUtente["cod_db"],
                        "id_utente": self.infoUtente["id_utente"],
                        "id_centralina": self.dispositivo["fk_centralina"],
                        "dt_misura": dataLettura, 
                        "rssi": "0"
                    }
                if power != None:
                    misuraPower = {
                        "id_sensore": self.dispositivo["id"],
                        "mac": self.dispositivo["mac"],
                        "val_misura": power, 
                        "tipo_misura": "W", 
                        "nome_misura": "Potenza", 
                        "cod_db": self.infoUtente["cod_db"],
                        "id_utente": self.infoUtente["id_utente"],
                        "id_centralina": self.dispositivo["fk_centralina"],
                        "dt_misura": dataLettura, 
                        "rssi": "0"
                    }
                if current != None:
                    misuraCurrent = {
                        "id_sensore": self.dispositivo["id"],
                        "mac": self.dispositivo["mac"],
                        "val_misura": current, 
                        "tipo_misura": "A", 
                        "nome_misura": "Corrente", 
                        "cod_db": self.infoUtente["cod_db"],
                        "id_utente": self.infoUtente["id_utente"],
                        "id_centralina": self.dispositivo["fk_centralina"],
                        "dt_misura": dataLettura, 
                        "rssi": "0"
                    }
                if voltage != None:
                    misuraVoltage = {
                        "id_sensore": self.dispositivo["id"],
                        "mac": self.dispositivo["mac"],
                        "val_misura": voltage, 
                        "tipo_misura": "V", 
                        "nome_misura": "Voltaggio", 
                        "cod_db": self.infoUtente["cod_db"],
                        "id_utente": self.infoUtente["id_utente"],
                        "id_centralina": self.dispositivo["fk_centralina"],
                        "dt_misura": dataLettura, 
                        "rssi": "0"
                    }
                if frequency != None:
                    misuraFrequency = {
                        "id_sensore": self.dispositivo["id"],
                        "mac": self.dispositivo["mac"],
                        "val_misura": frequency, 
                        "tipo_misura": "Hz", 
                        "nome_misura": "Frequenza", 
                        "cod_db": self.infoUtente["cod_db"],
                        "id_utente": self.infoUtente["id_utente"],
                        "id_centralina": self.dispositivo["fk_centralina"],
                        "dt_misura": dataLettura, 
                        "rssi": "0"
                    }
                
                self.threadMisure.scriviMisure(self.mqtts, misuraEnergyCounter, misuraPower, misuraCurrent, misuraVoltage, misuraFrequency)

                try:
                    datiSensore = proxy.getParamset(mac_xmlrpc + ":2", "VALUES")
                    self.salvaValoreAtt(datiSensore["STATE"])
                except: pass

                return True
        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
            pass
        return False


    def setStatusAttuazione(self:dict, status:dict) -> bool:
        """
        Funzione che attiva disattiva il relay associato al dispositivo di attuazione

        Args:
            status (dict): Stato dell'attuazione [es. {"value": True}]

        Returns:
            bool: True se la modifica è avvenuta con successo, False se si sono verificati errori
        """
        try:
            if type(status["value"]) is str:
                status["value"] = status["value"].lower() in ["1.0", "true"]
          
            scriviLog.info("Setto temperatura del dispositivo %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
            user = chiamate_comuni.CCU3_USER
            password = chiamate_comuni.CCU3_PWD
            ip_centrale = chiamate_comuni.getIpCCU3()
            
            mac_xmlrpc = str(self.dispositivo["mac"])

            scriviLog.info("[CCU3] connessione a http://%s:%s@%s:2010/", user, password, ip_centrale)
            with xmlrpc.client.ServerProxy("http://"+user+":"+password+"@"+ip_centrale+":2010/") as proxy:
                proxy.init(ip_centrale, "1")           
                proxy.setValue(mac_xmlrpc + ":2", "STATE", status["value"])
                self.salvaValoreAtt(status["value"])

                return True
        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
        return False

    def salvaValoreAtt(self:dict, value:bool) -> bool:
        """
        Funzione salva il valore passato sul database se è diverso da quello precedente

        Args:
            value (bool): Valore del relay

        Returns:
            bool: True se la lettura è avvenuta con successo, False se si sono verificati errori
        """
        try:
            if self.valorePrecedente != value:
                dataLettura = datetime.utcnow().replace(tzinfo=TZ_UTC).strftime(FORMAT_DATA_TZ)
                lettura = {
                        "id_sensore": self.dispositivo["id"],
                        "mac": self.dispositivo["mac"],
                        "val_misura": 1 if value else 0, 
                        "tipo_misura": "On/Off", 
                        "nome_misura": "Accensione", 
                        "cod_db": self.infoUtente["cod_db"],
                        "id_utente": self.infoUtente["id_utente"],
                        "id_centralina": self.dispositivo["fk_centralina"],
                        "dt_misura": dataLettura, 
                        "rssi": 0
                    }
                
                self.threadMisure.scriviMisure(self.mqtts, lettura)
                self.valorePrecedente = value

            return True
        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
        return False


def main(dispositivo:dict, mqtts:dict, infoUtente:dict, **kwargs) -> Thread:
    """Funzione che avvia il thread di lettura del dispositivo

    Args:
        dispositivo (dict): Dispositivo da leggere
        mqtts (dict): Lista di mqtt
        infoUtente (dict): Dati dell'utente

    Returns:
        Thread: Riferimento al thread del dispositivo
    """
    threadMisure = kwargs["process_misure"] if "process_misure" in kwargs else None
    threadDispositivo = ThreadDispositivo("thread_lettura_dispositivo-" + dispositivo["id"], dispositivo, mqtts, infoUtente, threadMisure)
    threadDispositivo.start()
    return threadDispositivo