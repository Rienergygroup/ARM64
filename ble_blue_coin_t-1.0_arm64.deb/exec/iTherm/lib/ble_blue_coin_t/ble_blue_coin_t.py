from datetime import datetime
from threading import Thread
from gestione_dispositivi import Master
from rienergy_ble_scanner import ThreadBleScanner

import pathlib
import sys
import time
import traceback
import pytz

pathCorrente = pathlib.Path(__file__).parent.parent.parent.resolve().as_posix()
sys.path.append(pathCorrente)

import rienergy_logger
import rienergy_mqtt
import scrivi_misure

scriviLog = rienergy_logger.getLogger(pathLog=pathCorrente)

FORMAT_DATA_TZ = "%Y-%m-%d %H:%M:%S.%f%z"

TZ_UTC = pytz.utc

class ThreadDispositivo(Thread):
    """Thread che recupera i dati del dispositivo ogni intervallo
    """
    def __init__(self, nome:str, dispositivo:dict, mqtts:dict, infoUtente:dict, master:Master, threadMisure:scrivi_misure.ProcessScrittuaFileMisure, configDispositivi:dict):
        Thread.__init__(self, name=nome)
        self.fine = False
        self.dispositivo = dispositivo
        self.mqtts = mqtts
        self.infoUtente = infoUtente
        self.master = master
        self.threadMisure = threadMisure
        self.configDispositivi = configDispositivi
        self.topicInfo = rienergy_mqtt.TOPIC_INFO.format(codDb=infoUtente["cod_db"], idUtente=infoUtente["id_utente"], idCentralina=infoUtente["id_centralina"])

    def run(self):
        while not self.fine:
            status = self.main()
            # Se la lettura del sensore è avvenuta correttamente attendo il suo tempo di intervallo,
            #  altrimenti ritento dopo pochi secondi
            msgStatus = rienergy_mqtt.TEMPLATE_MSG_STATUS_DEVICE
            msgStatus["id_dispositivo"] = self.dispositivo["id"]
            msgStatus["status"] = status
            rienergy_mqtt.inviaMessaggio(msg=msgStatus, topic=self.topicInfo, mqtts=self.mqtts, filterMqtt="com")
            
            tAttesa = int(self.dispositivo["intervallo"])
            if not status:
                tAttesa = self.configDispositivi["intervallo_errore"]
            time.sleep(tAttesa)

    def main(self) -> bool:
        """Funzione che recupera i dati del dispositivo e li scrive nel file misure e in mqtt
    
        Args:
            self (dict): Istanza del thread contenente il JSON del dispositivo
        
        Returns:
            Boolean: Ritrona True se è stato letto tutto correttamente, False se si sono verficati errori
        """
        try:
            scriviLog.info("Recupero dati per il dispositivo %s ", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
            bleScanner:ThreadBleScanner = self.master.getThreadBleScanner()
            devices = []
            found = False
            try:
                if bleScanner is not None:
                    devices = bleScanner.getDispositiviTrovati()
            except Exception as e:
                scriviLog.error("Errore nel main di ble_blue_coin_t.py: %s\n%s", e, traceback.format_exc())
                pass
            
            for d in devices:
                if d.address.upper() == self.dispositivo["mac"].upper():
                    found = True
                    servizi = d.details["props"]["ServiceData"]
                    for pos in servizi:
                        # Controllo tutti i servizi in cui è possibile recuperare i dati
                        try:
                            dataLettura = datetime.utcnow().replace(tzinfo=TZ_UTC).strftime(FORMAT_DATA_TZ)
                            dati = servizi[pos].hex().upper()
                            temp = int(dati[2] + dati[3] + dati[0] + dati[1], 16) / 100

                            scriviLog.info(self.dispositivo["descrizione"] + " " + self.dispositivo["mac"] + "\n Temperatura: %s", 
                            temp)
                            misuraTemp = {
                                "id_sensore": self.dispositivo["id"],
                                "mac": self.dispositivo["mac"],
                                "val_misura": temp, 
                                "tipo_misura": "°C", 
                                "nome_misura": "Temperatura", 
                                "cod_db": self.infoUtente["cod_db"],
                                "id_utente": self.infoUtente["id_utente"],
                                "id_centralina": self.dispositivo["fk_centralina"],
                                "dt_misura": dataLettura, 
                                "rssi": d.rssi
                            }

                            self.threadMisure.scriviMisure(self.mqtts, misuraTemp)

                            return True
                        except: pass
                    break
        except Exception as e:
            scriviLog.error("Errore dispositivo %s: %s\n%s", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"], e, traceback.format_exc())
            pass
        if not found:
            scriviLog.error("Non sono riuscito a trovare %s nella lista dei dispositivi BLE", self.dispositivo["descrizione"] + " " + self.dispositivo["mac"])
        return False

def main(dispositivo:dict, mqtts:dict, infoUtente:dict, **kwargs) -> Thread:
    """Funzione che avvia il thread di lettura del dispositivo

    Args:
        dispositivo (dict): Dispositivo da leggere
        mqtts (dict): Lista di mqtt
        infoUtente (dict): Dati dell'utente

    Returns:
        Thread: Riferimento al thread del dispositivo
    """
    master = kwargs["master"] if "master" in kwargs else None
    threadMisure = kwargs["process_misure"] if "process_misure" in kwargs else None
    configDispositivi = kwargs["config_dispositivi"] if "config_dispositivi" in kwargs else {}
    threadDispositivo = ThreadDispositivo("thread_lettura_dispositivo-" + dispositivo["id"], dispositivo, mqtts, infoUtente, master, threadMisure, configDispositivi)
    threadDispositivo.start()
    return threadDispositivo



if __name__ == "__main__":
    main({
        "id": "1",
        "descrizione": "Sensore esterno",
        "mac": "F9:07:F4:90:09:07",
        "url_interno": "",
        "url_esterno": "",
        "user": "",
        "password": "",
        "intervallo": "20",
        "alimentazione": "",
        "tensione": "",
        "nome_pacchetto": "a",
        "nome_eseguibile": "a.py"
    }, [], {"cod_db": "100", "id_utente": "1"})